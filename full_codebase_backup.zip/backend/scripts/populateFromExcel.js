import mongoose from 'mongoose';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

import User from '../models/User.js';
import Domain from '../models/Domain.js';
import AuditPlan from '../models/AuditPlan.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '../.env') });

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGO_URI || process.env.MONGODB_URI;
    await mongoose.connect(mongoURI);
    console.log('✅ Connected to MongoDB Atlas');
  } catch (err) {
    console.error('❌ Connection error:', err.message);
    process.exit(1);
  }
};

const runMigration = async () => {
  await connectDB();

  console.log('--- Step 1: Merging Users ---');
  const excelUsers = [
    { name: 'Ravindra Murthy', email: 'systems@rashtrotthana.org', phone: '9845169587', role: 'Admin' },
    { name: 'Lokesh B.S', email: 'lokeshbs@rashtrotthana.org', phone: '98454 42797', role: 'Admin' },
    { name: 'Ashish Sabnis', email: 'ashish.s@rashtrotthana.org', phone: '9980016670', role: 'Admin' },
    { name: 'Vani.M', email: 'vani.mh@rashtrotthana.org', phone: '9036808549', role: 'Coordinator' },
    { name: 'Shreyanka', email: 'shreyanka.s@rashtrotthana.org', phone: '9742530586', role: 'Coordinator' },
    { name: 'Roopashree', email: 'roopashree.gs@rashtrotthana.org', phone: '9844530423', role: 'Coordinator' },
    { name: 'Gururaj', email: 'gururaj.bs@rashtrotthana.org', phone: '9742613133', role: 'Coordinator' },
    { name: 'Ranganath', email: 'ranganath.hs@rashtrotthana.org', phone: '6361696563', role: 'Coordinator' },
    { name: 'Venkoba Rao', email: 'admin@rashtrotthana.org', phone: '9880366648', role: 'Coordinator' },
    { name: 'Jayaram Naik', email: 'transportation@rashtrotthana.org', phone: '6238365063', role: 'Coordinator' },
    { name: 'Super Admin', email: 'admin@pratibimba.com', phone: '0000000000', role: 'Super Admin' }
  ];

  for (const u of excelUsers) {
    const existing = await User.findOne({ email: u.email.toLowerCase() });
    if (!existing) {
      await User.create({
        username: u.email.toLowerCase(),
        email: u.email.toLowerCase(),
        name: u.name,
        phone: u.phone,
        role: u.role,
        password: '$2a$10$e84.v/b.bA4E5.mO4k/YxO2SgqZ8J1A5e.p8r.0O.k5.M' // test123 default
      });
      console.log(` + Added missing user: ${u.email}`);
    } else {
      // Safely preserve existing fields, append only missing attributes
      if (!existing.phone && u.phone) existing.phone = u.phone;
      if (!existing.name && u.name) existing.name = u.name;
      await existing.save();
      console.log(` ~ Preserved existing user: ${u.email}`);
    }
  }

  console.log('\n✅ Data sync complete without overwriting existing fields.');
  process.exit(0);
};

runMigration();
